#!/usr/bin/env bash
# ============================================================
#  SVM Panel (AnkitCoder) - Full Installer
#  QEMU/KVM + LXC/LXD + Node.js + Bridge + systemd
# ============================================================
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

PANEL_NAME="SVM Panel"
PANEL_USER="${SUDO_USER:-$USER}"
INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-8080}"
NODE_MAJOR=20
BRIDGE_NAME="vmbr0"

log()  { echo -e "${GREEN}[✓]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*" >&2; }
info() { echo -e "${CYAN}[*]${NC} $*"; }
die()  { err "$*"; exit 1; }

banner() {
  clear
  echo -e "${CYAN}${BOLD}"
  cat << 'EOF'
╔════════════════════════════════════════════════════════════╗
║         SVM PANEL - FULL INSTALLER (AnkitCoder)            ║
║     QEMU/KVM + LXC/LXD + Node.js + Bridge Networking       ║
╚════════════════════════════════════════════════════════════╝
EOF
  echo -e "${NC}"
}

need_root() {
  if [[ $EUID -ne 0 ]]; then
    die "Root required. Run: sudo bash install.sh"
  fi
}

detect_os() {
  if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    . /etc/os-release
    OS_ID="${ID:-unknown}"
    OS_VERSION="${VERSION_ID:-}"
  else
    die "Cannot detect OS. Supported: Ubuntu 20.04+/Debian 11+"
  fi
  case "$OS_ID" in
    ubuntu|debian) log "Detected: $PRETTY_NAME" ;;
    *)
      warn "OS $OS_ID is not officially tested. Continuing for Debian-like systems..."
      ;;
  esac
}

check_virt() {
  info "Checking CPU virtualization support..."
  if grep -Eq 'vmx|svm' /proc/cpuinfo; then
    log "Hardware virtualization (VT-x/AMD-V) detected"
  else
    warn "No VT-x/AMD-V in /proc/cpuinfo — KVM may not work (nested virt / cloud VM?)"
  fi
  if [[ -e /dev/kvm ]]; then
    log "/dev/kvm present"
  else
    warn "/dev/kvm missing — will still install packages"
  fi
}

apt_update() {
  info "Updating package lists..."
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
}

install_base() {
  info "Installing base packages..."
  apt-get install -y -qq \
    curl wget git ca-certificates gnupg lsb-release \
    build-essential python3 python3-pip \
    sqlite3 unzip tar \
    net-tools iproute2 bridge-utils \
    genisoimage cloud-image-utils \
    qemu-utils \
    > /dev/null
  log "Base packages installed"
}

install_qemu_kvm() {
  info "Installing QEMU/KVM + libvirt stack..."
  apt-get install -y -qq \
    qemu-system \
    qemu-system-x86 \
    qemu-system-arm \
    qemu-kvm \
    libvirt-daemon-system \
    libvirt-clients \
    virtinst \
    virt-manager \
    ovmf \
    seabios \
    cpu-checker \
    > /dev/null 2>&1 || apt-get install -y -qq \
    qemu-system qemu-kvm libvirt-daemon-system libvirt-clients virtinst ovmf \
    > /dev/null

  # Groups
  usermod -aG kvm,libvirt "$PANEL_USER" 2>/dev/null || true
  if [[ -e /dev/kvm ]]; then
    chown root:kvm /dev/kvm 2>/dev/null || true
    chmod 666 /dev/kvm 2>/dev/null || true
  fi

  systemctl enable --now libvirtd 2>/dev/null || systemctl enable --now libvirt-bin 2>/dev/null || true
  log "QEMU/KVM + libvirt installed"
}

install_lxc() {
  info "Installing LXC + LXD (full container stack)..."
  # LXC classic tools
  apt-get install -y -qq \
    lxc \
    lxc-templates \
    lxcfs \
    uidmap \
    > /dev/null 2>&1 || true

  # LXD via snap (preferred on Ubuntu) or apt
  if command -v snap >/dev/null 2>&1; then
    snap install lxd 2>/dev/null || true
    if command -v lxd >/dev/null 2>&1; then
      # Non-interactive minimal init if not already initialized
      if ! lxc network list >/dev/null 2>&1; then
        cat << 'LXDEOF' | lxd init --preseed 2>/dev/null || true
config: {}
networks:
- config:
    ipv4.address: auto
    ipv6.address: none
  description: ""
  name: lxdbr0
  type: bridge
storage_pools:
- config:
    size: 20GB
  description: ""
  name: default
  driver: dir
profiles:
- config: {}
  description: ""
  devices:
    eth0:
      name: eth0
      network: lxdbr0
      type: nic
    root:
      path: /
      pool: default
      type: disk
  name: default
cluster: null
LXDEOF
      fi
      usermod -aG lxd "$PANEL_USER" 2>/dev/null || true
      log "LXD installed and initialized (lxdbr0)"
    fi
  else
    apt-get install -y -qq lxd 2>/dev/null || warn "LXD snap/apt not available — LXC tools only"
  fi

  if command -v lxc >/dev/null 2>&1; then
    log "LXC tools available: $(lxc --version 2>/dev/null || lxc-ls --version 2>/dev/null || echo ok)"
  else
    warn "lxc binary not found after install"
  fi
}

install_nodejs() {
  info "Installing Node.js ${NODE_MAJOR}.x..."
  if command -v node >/dev/null 2>&1; then
    local ver
    ver=$(node -v | sed 's/v//;s/\..*//')
    if [[ "$ver" -ge 18 ]]; then
      log "Node.js already present: $(node -v)"
      return
    fi
  fi

  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs >/dev/null
  log "Node.js $(node -v) / npm $(npm -v)"
}

setup_bridge() {
  info "Setting up bridge interface: ${BRIDGE_NAME}..."

  # Skip if already exists
  if ip link show "$BRIDGE_NAME" >/dev/null 2>&1; then
    log "Bridge ${BRIDGE_NAME} already exists"
    return
  fi

  # Detect primary interface (default route)
  local IFACE
  IFACE=$(ip route show default 2>/dev/null | awk '/default/ {print $5; exit}')
  if [[ -z "${IFACE:-}" ]]; then
    warn "No default interface found — skip auto bridge. Create ${BRIDGE_NAME} manually later."
    return
  fi

  # Only create empty bridge (safe) — do NOT steal primary NIC automatically
  # (Stealing NIC can drop SSH). Documented for user.
  ip link add name "$BRIDGE_NAME" type bridge 2>/dev/null || true
  ip link set "$BRIDGE_NAME" up 2>/dev/null || true
  log "Created empty bridge ${BRIDGE_NAME} (up). Primary NIC left untouched for SSH safety."
  warn "To attach real NIC to ${BRIDGE_NAME}, edit /etc/netplan or use: ip link set ${IFACE} master ${BRIDGE_NAME}"
}

setup_dirs() {
  info "Creating panel directories..."
  local HOME_DIR
  HOME_DIR=$(eval echo "~${PANEL_USER}")
  mkdir -p "${HOME_DIR}/vms"/{templates,iso,cloudvm}
  mkdir -p "${HOME_DIR}/.svm"
  chown -R "${PANEL_USER}:${PANEL_USER}" "${HOME_DIR}/vms" "${HOME_DIR}/.svm"
  log "VM dir: ${HOME_DIR}/vms"
  log "Data dir: ${HOME_DIR}/.svm"
}

install_panel() {
  info "Installing Node dependencies in ${INSTALL_DIR}..."
  cd "$INSTALL_DIR"
  if [[ ! -f package.json ]]; then
    die "package.json not found in ${INSTALL_DIR}"
  fi
  # Run npm as panel user when possible
  if [[ "$PANEL_USER" != "root" ]] && id "$PANEL_USER" >/dev/null 2>&1; then
    su - "$PANEL_USER" -c "cd '${INSTALL_DIR}' && npm install --omit=dev" || npm install --omit=dev
  else
    npm install --omit=dev
  fi
  log "npm packages installed"
}

create_env() {
  local env_file="${INSTALL_DIR}/.env"
  if [[ -f "$env_file" ]]; then
    log ".env already exists — keeping it"
    return
  fi
  cat > "$env_file" << EOF
PORT=${PORT}
PANEL_NAME=SVM Panel
PANEL_VERSION=V3.0
DEFAULT_LOGO_URL=/public/images/logo.svg
SVM_DATA_DIR=
EOF
  chown "${PANEL_USER}:${PANEL_USER}" "$env_file" 2>/dev/null || true
  log "Created .env (PORT=${PORT})"
}

create_systemd() {
  info "Creating systemd service: svm-panel.service..."
  local NODE_BIN
  NODE_BIN=$(command -v node)

  cat > /etc/systemd/system/svm-panel.service << EOF
[Unit]
Description=SVM Panel (AnkitCoder) - VM Management
After=network.target libvirtd.service
Wants=libvirtd.service

[Service]
Type=simple
User=${PANEL_USER}
Group=${PANEL_USER}
WorkingDirectory=${INSTALL_DIR}
Environment=NODE_ENV=production
Environment=PORT=${PORT}
EnvironmentFile=-${INSTALL_DIR}/.env
ExecStart=${NODE_BIN} ${INSTALL_DIR}/app.js
Restart=on-failure
RestartSec=5
LimitNOFILE=65535

# Allow KVM / networking
SupplementaryGroups=kvm libvirt lxd

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable svm-panel.service
  log "systemd unit enabled (svm-panel.service)"
}

start_panel() {
  info "Starting SVM Panel..."
  systemctl restart svm-panel.service
  sleep 2
  if systemctl is-active --quiet svm-panel.service; then
    log "Service is running"
  else
    warn "Service may have failed — check: journalctl -u svm-panel -n 50"
    systemctl status svm-panel.service --no-pager || true
  fi
}

print_summary() {
  local IP
  IP=$(hostname -I 2>/dev/null | awk '{print $1}')
  echo ""
  echo -e "${GREEN}${BOLD}══════════════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}${BOLD}  INSTALL COMPLETE — SVM Panel (AnkitCoder)${NC}"
  echo -e "${GREEN}${BOLD}══════════════════════════════════════════════════════════${NC}"
  echo ""
  echo -e "  Panel URL : ${CYAN}http://${IP:-YOUR_IP}:${PORT}${NC}"
  echo -e "  Local     : ${CYAN}http://127.0.0.1:${PORT}${NC}"
  echo -e "  Install   : ${INSTALL_DIR}"
  echo -e "  Service   : systemctl status svm-panel"
  echo -e "  Logs      : journalctl -u svm-panel -f"
  echo ""
  echo -e "  ${BOLD}Stack installed:${NC}"
  echo "    • Node.js $(node -v 2>/dev/null || echo n/a)"
  echo "    • QEMU/KVM + libvirt"
  echo "    • LXC + LXD (if available)"
  echo "    • Bridge: ${BRIDGE_NAME}"
  echo "    • cloud-image-utils / genisoimage"
  echo ""
  echo -e "  ${YELLOW}Note:${NC} Log out/in (or new SSH) so group kvm/libvirt/lxd apply."
  echo -e "  ${YELLOW}Note:${NC} Default admin is created on first run (check app logs)."
  echo ""
}

# -------------------- main --------------------
main() {
  banner
  need_root
  detect_os
  check_virt
  apt_update
  install_base
  install_qemu_kvm
  install_lxc
  install_nodejs
  setup_bridge
  setup_dirs
  install_panel
  create_env
  create_systemd
  start_panel
  print_summary
}

main "$@"
